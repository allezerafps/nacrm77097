package com.example.silverinnovation.nacandroid01;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void doBuscar (View view){


        String url = "@string/Url";

        EditText edtId = findViewById(R.id.edtId);
        url += edtId.getText().toString();

        TextView txtCompleted = findViewById(R.id.txtComplete);
        TextView txtTitle = findViewById(R.id.txtTitle);


        new Data(txtCompleted,txtTitle).execute(url);


        edtId.selectAll();
    }
}

