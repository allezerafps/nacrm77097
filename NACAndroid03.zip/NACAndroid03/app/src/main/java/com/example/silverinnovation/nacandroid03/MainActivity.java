package com.example.silverinnovation.nacandroid03;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText edtTitulo;
    private EditText edtConteudo;
    private final String NÃO_ACHOU = "NOTA NÃO LOCALIZADA";
    private final String DICIONARIO = "NOTAS";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void doAdd(View view)
    {

        edtTitulo = (EditText) findViewById(R.id.edtTitulo);
        edtConteudo = (EditText) findViewById(R.id.edtConteudo);

        String titulo = edtTitulo.getText().toString();
        String conteudo = edtConteudo.getText().toString();


        SharedPreferences sh = getSharedPreferences(DICIONARIO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sh.edit();


        ed.putString(titulo, conteudo);

        ed.apply();

        edtTitulo.setText("");
        edtConteudo.setText("");

        Toast.makeText(this, "Nota (" + titulo + ") foi adicionada", Toast.LENGTH_LONG).show();
    }

    public void doBusca(View view)
    {

        edtTitulo = (EditText) findViewById(R.id.edtTitulo);
        edtConteudo = (EditText) findViewById(R.id.edtConteudo);

        String titulo = edtTitulo.getText().toString();

        SharedPreferences sh = getSharedPreferences(DICIONARIO, Context.MODE_PRIVATE);

        String conteudo = sh.getString(titulo, NÃO_ACHOU);

        if(conteudo == NÃO_ACHOU)
        {
            Toast.makeText(this, "Essa nota não existe !" + titulo, Toast.LENGTH_LONG).show();
        }
        else
        {
            edtConteudo.setText(conteudo);
        }
    }



}
